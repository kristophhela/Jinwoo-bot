jin ɓot 

jin bot don't clone
